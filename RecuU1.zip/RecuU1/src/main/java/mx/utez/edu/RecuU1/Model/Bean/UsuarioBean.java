package mx.utez.edu.RecuU1.Model.Bean;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@NoArgsConstructor
@Setter
@Getter
@Table(name="Usuarios")
public class UsuarioBean {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(length = 30, nullable = false, unique = true)
    private String Usunombre;
    @Column(length = 8, nullable = false)
    private String password;
    @Column(columnDefinition = "BOOL DEFAULT true")
    private boolean estado;
}