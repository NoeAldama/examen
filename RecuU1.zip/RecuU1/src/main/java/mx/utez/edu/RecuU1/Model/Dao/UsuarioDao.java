package mx.utez.edu.RecuU1.Model.Dao;

import mx.utez.edu.RecuU1.Model.Bean.UsuarioBean;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UsuarioDao extends JpaRepository<UsuarioBean, Long> {
}
