package mx.utez.edu.RecuU1.Model.Dao;

import mx.utez.edu.RecuU1.Model.Bean.ClienteBean;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClienteDao extends JpaRepository<ClienteBean, Long> {
}
