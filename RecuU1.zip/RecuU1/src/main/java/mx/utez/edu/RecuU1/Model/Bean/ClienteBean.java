package mx.utez.edu.RecuU1.Model.Bean;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@NoArgsConstructor
@Setter
@Getter
@Table(name="clientes")
public class ClienteBean {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "nombres",length = 30, nullable = false)
    private String nombres;
    @Column(name = "apellido1", length = 30, nullable = false)
    private String apellido1;
    @Column(name = "apellido2", length = 30, nullable = false)
    private String apellido2;
    @Column(name = "telefono", length = 10, nullable = false)
    private String telefono;
}
