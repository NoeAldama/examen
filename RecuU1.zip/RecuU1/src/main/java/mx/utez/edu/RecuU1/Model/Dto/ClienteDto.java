package mx.utez.edu.RecuU1.Model.Dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
public class ClienteDto {

    private Long id;
    private String nombres;
    private String Apellido1;
    private String Apellido2;
    private String telefono;
}
