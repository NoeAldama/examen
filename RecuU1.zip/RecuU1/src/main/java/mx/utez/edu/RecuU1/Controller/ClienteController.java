package mx.utez.edu.RecuU1.Controller;

import mx.utez.edu.RecuU1.Model.Bean.ClienteBean;
import mx.utez.edu.RecuU1.Service.Impl.ClienteImpl;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/clientes/")
@CrossOrigin(origins = {"*"})
public class ClienteController {
    private final ClienteImpl service;

    public ClienteController(ClienteImpl service) {
        this.service = service;
    }

    @GetMapping("")
    public ResponseEntity getAll() {
        return ResponseEntity.ok(service.readAll());
    }

    @GetMapping("{id}")
    public ResponseEntity getById(@PathVariable Long id) {
        return ResponseEntity.ok(service.getById(id));
    }

    @PostMapping("")
    public ResponseEntity register(@RequestBody ClienteBean person) {
        return ResponseEntity.ok(service.save(person));
    }

    @PutMapping("")
    public ResponseEntity update(@RequestBody ClienteBean person) {
        return ResponseEntity.ok(service.save(person));
    }

    @DeleteMapping("{id}")
    public ResponseEntity delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.ok("Cliente borrado correctamente");

    }
}
