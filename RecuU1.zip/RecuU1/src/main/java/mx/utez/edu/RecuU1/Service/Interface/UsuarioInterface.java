package mx.utez.edu.RecuU1.Service.Interface;

import mx.utez.edu.RecuU1.Model.Bean.UsuarioBean;

import java.util.List;

public interface UsuarioInterface{
    UsuarioBean save(UsuarioBean personBean);
    List<UsuarioBean> readAll();
    void delete(Long id);
    UsuarioBean getById(Long id);}
