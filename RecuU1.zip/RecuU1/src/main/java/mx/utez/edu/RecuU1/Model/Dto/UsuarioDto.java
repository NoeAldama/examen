package mx.utez.edu.RecuU1.Model.Dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class UsuarioDto {
    private Long id;
    private String nombreUsu;
    private String password;
    private boolean estado;
}
