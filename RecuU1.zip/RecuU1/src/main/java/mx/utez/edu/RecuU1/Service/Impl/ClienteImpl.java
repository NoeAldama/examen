package mx.utez.edu.RecuU1.Service.Impl;

import mx.utez.edu.RecuU1.Model.Bean.ClienteBean;
import mx.utez.edu.RecuU1.Model.Dao.ClienteDao;
import mx.utez.edu.RecuU1.Service.Interface.ClienteInterface;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.SQLException;
import java.util.List;

@Service
@Transactional
public class ClienteImpl implements ClienteInterface {
    private final ClienteDao inter;

    public ClienteImpl(ClienteDao inter) {
        this.inter = inter;
    }

    @Transactional(rollbackFor = {SQLException.class})
    @Override
    public ClienteBean save(ClienteBean clienteBean) {
        return inter.saveAndFlush(clienteBean);
    }

    @Transactional(readOnly = true, rollbackFor = {SQLException.class})
    @Override
    public List<ClienteBean> readAll() {
        return inter.findAll();
    }

    @Transactional
    public void delete(Long id) {
        inter.deleteById(id);
    }

    @Transactional(readOnly = true, rollbackFor = {SQLException.class})
    @Override
    public ClienteBean getById(Long id) {
        return (inter.findById(id).isPresent() ? inter.findById(id).get() : null);
    }
}
