package mx.utez.edu.RecuU1.Service.Interface;

import mx.utez.edu.RecuU1.Model.Bean.ClienteBean;

import java.util.List;

public interface ClienteInterface {
    ClienteBean save(ClienteBean clienteBean);
    List<ClienteBean> readAll();
    void delete(Long id);
    ClienteBean getById(Long id);
}
