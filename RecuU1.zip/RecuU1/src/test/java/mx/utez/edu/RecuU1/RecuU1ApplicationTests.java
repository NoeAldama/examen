package mx.utez.edu.RecuU1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecuU1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
